<?php
/*
|--------------------------------------------------------------------------
| Shared password strength policy
|--------------------------------------------------------------------------
| Used by: account.php (student signup), update_password.php (forced
| change), reset_password.php (forgot-password reset), settings.php
| (voluntary password change).
|
| Rule: at least 8 characters, with at least one uppercase letter, one
| lowercase letter, one number, and one special character. This blocks
| purely numeric or all-lowercase "basic" passwords while staying easy
| to explain to end users.
|--------------------------------------------------------------------------
*/

function rmc_password_is_strong(string $password): bool
{
    if (strlen($password) < 8) {
        return false;
    }
    if (!preg_match('/[a-z]/', $password)) {
        return false;
    }
    if (!preg_match('/[A-Z]/', $password)) {
        return false;
    }
    if (!preg_match('/[0-9]/', $password)) {
        return false;
    }
    if (!preg_match('/[^a-zA-Z0-9]/', $password)) {
        return false;
    }
    return true;
}

function rmc_password_policy_message(): string
{
    return 'Password must be at least 8 characters and include an uppercase letter, '
        . 'a lowercase letter, a number, and a special character (e.g. Campus@2026).';
}

/* HTML5 pattern for client-side hinting only — the server check above is
   what actually enforces the rule, so this never needs to be kept in
   perfect sync for security purposes. */
function rmc_password_policy_pattern(): string
{
    return '(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}';
}
