<?php
// TEMPORARY DIAGNOSTIC - delete this file once the real cause is found.
// Open:  https://YOUR-SITE/diag.php?key=rmc-diag-2026
if (($_GET['key'] ?? '') !== 'rmc-diag-2026') { http_response_code(404); exit; }
header('Content-Type: text/plain; charset=utf-8');
ini_set('display_errors', '1'); error_reporting(E_ALL);
function line($ok, $msg) { echo ($ok === null ? '[INFO] ' : ($ok ? '[ OK ] ' : '[FAIL] ')) . $msg . "\n"; }

echo "RMC EVENTS DIAGNOSTIC\n=====================\n";
line(null, 'PHP ' . PHP_VERSION . ' | host header: ' . ($_SERVER['HTTP_HOST'] ?? '?'));

$cfgFile = __DIR__ . '/config.local.php';
$cfg = is_file($cfgFile) ? require $cfgFile : null;
if (!is_array($cfg)) { line(false, 'config.local.php missing or invalid'); exit; }
line(true, 'config.local.php loaded (host=' . ($cfg['db_host'] ?? '') . ', db=' . ($cfg['db_name'] ?? '') . ', user=' . ($cfg['db_user'] ?? '') . ', pass length=' . strlen($cfg['db_pass'] ?? '') . ')');

try {
    $pdo = new PDO("mysql:host={$cfg['db_host']};port={$cfg['db_port']};dbname={$cfg['db_name']};charset=utf8mb4",
        $cfg['db_user'], $cfg['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    line(true, 'Database connection works');
} catch (Throwable $e) {
    line(false, 'Database connection FAILED: ' . $e->getMessage());
    exit;
}

$need = [
    'users' => ['user_id','student_id','email','role','status','password','must_change_password'],
    'email_verifications' => ['full_name','student_id','department','role','email','password_hash','verification_code','expires_at','attempts','created_at'],
    'email_logs' => ['recipient_email','subject','message','status','created_at'],
    'email_queue' => ['recipient_email','subject','message_body','status','attempts'],
    'rate_limits' => ['rate_key','attempt_time'],
    'system_settings' => ['setting_key','setting_value'],
];
foreach ($need as $table => $cols) {
    try {
        $have = $pdo->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_COLUMN);
        $missing = array_diff($cols, $have);
        line(!$missing, "table $table" . ($missing ? ' is MISSING columns: ' . implode(', ', $missing) : ' looks good'));
    } catch (Throwable $e) {
        line(false, "table $table: " . $e->getMessage());
    }
}

try {
    $pdo->beginTransaction();
    $pdo->prepare("INSERT INTO email_verifications (full_name, student_id, department, role, email, password_hash, verification_code, expires_at, attempts, created_at) VALUES (?,?,?,?,?,?,?,?,0,NOW())")
        ->execute(['Diag Test','DIAG-1','IT','student','diag@example.com','x','123456',date('Y-m-d H:i:s', time()+600)]);
    line(true, 'INSERT into email_verifications works');
    $pdo->prepare("INSERT INTO email_logs (recipient_email, subject, message, status, created_at) VALUES (?,?,?,'Sent',NOW())")
        ->execute(['diag@example.com','diag','diag']);
    line(true, 'INSERT into email_logs works');
    $pdo->rollBack();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    line(false, 'Write test FAILED: ' . $e->getMessage());
}

foreach ([587, 465] as $port) {
    $errno = 0; $errstr = '';
    $t = microtime(true);
    $fp = @fsockopen(($port === 465 ? 'ssl://' : '') . 'smtp.gmail.com', $port, $errno, $errstr, 6);
    $ms = round((microtime(true) - $t) * 1000);
    if ($fp) { line(true, "smtp.gmail.com:$port reachable ({$ms}ms)"); fclose($fp); }
    else { line(false, "smtp.gmail.com:$port NOT reachable after {$ms}ms -> [$errno] $errstr"); }
}

$emailCfgFile = __DIR__ . '/email_config.local.php';
$emailCfg = is_file($emailCfgFile) ? @include $emailCfgFile : null;
if (is_array($emailCfg)) {
    line(true, 'email_config.local.php loaded (host=' . ($emailCfg['host'] ?? '?') . ', username set: ' . (empty($emailCfg['username']) ? 'NO' : 'yes') . ', password set: ' . (empty($emailCfg['password']) ? 'NO' : 'yes') . ')');
} else {
    line(false, 'email_config.local.php missing or invalid');
}

echo "\nDone. Send the FULL output above. Then DELETE diag.php from htdocs.\n";
