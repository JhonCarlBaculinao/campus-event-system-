<?php
/*
|--------------------------------------------------------------------------
| LIVE SMTP CONFIG (InfinityFree)
|--------------------------------------------------------------------------
| Fill in your own Gmail address and App Password below, then upload this
| file into the same folder as your other PHP files on InfinityFree
| (htdocs/). Do NOT commit real credentials into any public repository.
|
| How to get a Gmail App Password:
| 1. Go to https://myaccount.google.com/security
| 2. Turn on 2-Step Verification if it isn't already on.
| 3. Go to https://myaccount.google.com/apppasswords
| 4. Create a new app password (name it e.g. "RMC Events") and copy the
|    16-character code it gives you — that's your password below,
|    NOT your normal Gmail login password.
|--------------------------------------------------------------------------
*/
return [
    'host'       => 'smtp.gmail.com',
    'port'       => 587,
    'encryption' => 'tls',
    'username'   => 'baculinaojhoncarl@gmail.com',
    'password'   => 'hswlicchzrvetmfx',
    'from_email' => 'baculinaojhoncarl@gmail.com',
    'from_name'  => 'Regis Marie College Event System',
];
