<?php
return [
    'db_host'  => 'sql206.infinityfree.com',
    'db_port'  => '3306',
    'db_name'  => 'if0_42767022_rmc',
    'db_user'  => 'if0_42767022',
    'db_pass'  => 'hJ6tys9apf',
    'hmac_key' => 'kQ8mZp2vLx9RtY4wNc7bJq3sHe6dFg1A',
];
